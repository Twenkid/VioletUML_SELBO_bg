package com.horstmann.violet.framework.network;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

public class NetworkConstant
{
    public static final String DEFAULT_HTTP_PORT = "9090";

    public static final String DEFAULT_USER_ID = "username";

    public static final String DEFAULT_SERVER_ID = "server";

    public static URL DEFAULT_HTTP_LOCAL_URL;

    public static final String HTTP_CONTEXT_URI = "/";

    public static final String HTTP_SENDING_METHOD = "POST";

    public static final String HTTP_PROTOCOL = "http";

    public static final String HTTP_CONTENT_TYPE = "application/x-www-form-urlencoded";

    public static final String HTTP_POSTED_INPUT_FIELD_NAME = "message";

    public static final String SENDING_SESSION_ID = "sendingSessionId";

    public static final String STARTING_SESSION_ID = "mockSessionId";

    static
    {
        try
        {
            String localIPAddress = InetAddress.getLocalHost().getHostAddress();
            NetworkConstant.DEFAULT_HTTP_LOCAL_URL = new URL("http://" + localIPAddress + ":" + NetworkConstant.DEFAULT_HTTP_PORT);
        }
        catch (UnknownHostException e)
        {
            // Well... we tried
        }
        catch (MalformedURLException e)
        {
            // Well... we tried
        }
    }

}
