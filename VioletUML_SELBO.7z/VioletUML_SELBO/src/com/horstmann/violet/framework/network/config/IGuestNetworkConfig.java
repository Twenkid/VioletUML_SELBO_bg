package com.horstmann.violet.framework.network.config;

import java.net.URL;

/**
 * Contains network config for a guest session (all needed to be connected to a host, in other words)
 * 
 * @author Alexandre de Pellegrin
 *
 */
public interface IGuestNetworkConfig extends INetworkConfig
{
    /**
     * @return user id
     */
    public String getUserID();
    
    /**
     * @return local url (we can suppose that guest machine has several urls)
     */
    public URL getLocalURL();
    
    /**
     * @return host url
     */
    public URL getServerURL();
    

}
