package com.horstmann.violet.framework.network;

import java.util.EventListener;

import com.horstmann.violet.framework.gui.DiagramPanel;

public interface NetworkManagerListener extends EventListener
{
    public void newDiagramPanelCreated(DiagramPanel newDiagramPanel);
    
    
}
