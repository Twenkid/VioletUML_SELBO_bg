package com.horstmann.violet.framework.network.sender;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.horstmann.violet.framework.diagram.GraphService;
import com.horstmann.violet.framework.network.NetworkConstant;
import com.horstmann.violet.framework.network.NetworkMessage;
import com.horstmann.violet.framework.network.NetworkMessageSubjectType;

/**
 * This class is an HTTP sender. It sends a Violet's network message to recipients
 * 
 * @author Victor Freches
 */
public class HTTPSender implements ISender
{

    /*
     * (non-Javadoc)
     * 
     * @see com.horstmann.violet.framework.network.sender.ISender#sendMessage(com.horstmann.violet.framework.network.NetworkMessage)
     */
    public void sendMessage(NetworkMessage msg)
    {
        String encodedMessage = null;
        try
        {
            String message = this.getString(msg);
            encodedMessage = URLEncoder.encode(message, "UTF-8");
            System.out.println(message);
        }
        catch (UnsupportedEncodingException e2)
        {
            // Well, we tried...
        }
        if (encodedMessage == null)
        {
            return;
        }

        String postData = NetworkConstant.HTTP_POSTED_INPUT_FIELD_NAME + "=" + encodedMessage;
        URL[] urls = msg.getTo();

        for (int i = 0; i < urls.length; i++)
        {
            Postman internalPostman = new Postman(urls[i], postData, this, msg);
            internalPostman.start();
        }
    }

    /**
     * Checks if a bad recipient URL passed maximum delay. If yes, send a self message to request this recipient to be removed from
     * recipients list
     * 
     * @param recipientURL
     * @param concernedMessage
     */
    synchronized void registerBadRecipient(URL recipientURL, NetworkMessage concernedMessage)
    {
        if (!this.badRecipientURL.containsKey(recipientURL))
        {
            this.badRecipientURL.put(recipientURL, new Long(new Date().getTime()));
        }
        if (this.badRecipientURL.containsKey(recipientURL))
        {
            Long startTime = (Long) this.badRecipientURL.get(recipientURL);
            if (startTime.longValue() + MAX_NOT_RESPONDING_DELAY * 1000 < new Date().getTime())
            {
                this.badRecipientURL.remove(recipientURL);
                String subject = NetworkMessageSubjectType.DISCONNECT_CLIENT.getPattern();
                NetworkMessage message = new NetworkMessage(concernedMessage.getFrom(), concernedMessage.getReplyAddress(),
                        subject, concernedMessage.getFrom());
                message.addRecipient(concernedMessage.getReplyAddress());
                this.sendMessage(message);
            }
        }
    }

    /**
     * Converts NetworkMessage to an UTF8 String
     * 
     * @param msg
     * @return string
     * @throws UnsupportedEncodingException
     */
    private String getString(NetworkMessage msg) throws UnsupportedEncodingException
    {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        GraphService.write(msg, out);
        return out.toString("UTF-8");
    }

    /**
     * Takes in charge messages sendings
     * 
     * @author Alexandre de Pellegrin
     */
    private class Postman extends Thread
    {

        Postman(URL recipient, String message, HTTPSender parent, NetworkMessage originalMsg)
        {
            this.message = message;
            this.recipientURL = recipient;
            this.parent = parent;
            this.originalMsg = originalMsg;
        }

        public void run()
        {
            BufferedWriter bw = null;
            HttpURLConnection connection = null;
            try
            {
                connection = (HttpURLConnection) recipientURL.openConnection();
                connection.setDoOutput(true);
                connection.setRequestMethod(NetworkConstant.HTTP_SENDING_METHOD);
                connection.setRequestProperty("Content-type", NetworkConstant.HTTP_CONTENT_TYPE);
                connection.connect();
                bw = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
                bw.write(message, 0, message.length());
                bw.flush();
                System.out.println("Code response =" + connection.getResponseCode());
            }
            catch (IOException e)
            {
                parent.registerBadRecipient(recipientURL, originalMsg);
            }
            finally
            {
                if (bw != null)
                {
                    try
                    {
                        bw.close();
                    }
                    catch (IOException e1)
                    {
                        // Well, we tried...
                    }
                }
                if (connection != null)
                {
                    connection.disconnect();
                }
            }
        }

        private URL recipientURL;
        private String message;
        private HTTPSender parent;
        private NetworkMessage originalMsg;
    }

    /**
     * Blacklisted URLs
     */
    private Map<URL, Long> badRecipientURL = new HashMap<URL, Long>();

    /**
     * Max delay after which a backlisted url is definitly removed from recipients (in seconds)
     */
    private static final int MAX_NOT_RESPONDING_DELAY = 1;

}
