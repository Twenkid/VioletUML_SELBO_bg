package com.horstmann.violet.framework.network.config;

import java.net.MalformedURLException;
import java.net.URL;

import com.horstmann.violet.framework.network.NetworkConstant;
import com.horstmann.violet.framework.preference.PreferencesConstant;
import com.horstmann.violet.framework.preference.PreferencesService;
import com.horstmann.violet.framework.preference.PreferencesServiceFactory;

/**
 * HTTP implementation for host network config
 * 
 * @author Alexandre de Pellegrin
 * 
 */
public class HTTPHostConfig implements IHostNetworkConfig
{
    /**
     * Default connstructor
     */
    public HTTPHostConfig()
    {
    }

    
    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.network.config.INetworkConfig#loadPreferedValues()
     */
    public void loadPreferedValues()
    {
        PreferencesService preferencesService = PreferencesServiceFactory.getInstance();
        String userID = preferencesService.get(PreferencesConstant.NETWORK_HOSTCONFIG_USERID, NetworkConstant.DEFAULT_USER_ID);
        String localURL = preferencesService.get(PreferencesConstant.NETWORK_HOSTCONFIG_HTTP_LOCALURL, NetworkConstant.DEFAULT_HTTP_LOCAL_URL
                .toString());
        this.setUserID(userID);
        try
        {
            URL url = new URL(localURL);
            this.setLocalIpAddress(url.getHost());
            this.setLocalIpPort(url.getPort() + "");
        }
        catch (MalformedURLException e)
        {
            this.setLocalIpPort(NetworkConstant.DEFAULT_HTTP_PORT);
        }
    }


    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.network.config.INetworkConfig#savePreferedValues()
     */
    public void savePreferedValues()
    {
        PreferencesService preferencesService = PreferencesServiceFactory.getInstance();
        preferencesService.put(PreferencesConstant.NETWORK_HOSTCONFIG_USERID, this.getUserID());
        preferencesService.put(PreferencesConstant.NETWORK_HOSTCONFIG_HTTP_LOCALURL, this.getLocalURL().toString());
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.horstmann.violet.framework.network.config.IHostNetworkConfig#getUserID()
     */
    public String getUserID()
    {
        return userID;
    }

    /**
     * Set user id
     * 
     * @param userID
     */
    public void setUserID(String userID)
    {
        this.userID = userID;
    }

    /**
     * @return local ip address
     */
    public String getLocalIpAddress()
    {
        return localIpAddress;
    }

    /**
     * Set local ip address
     * 
     * @param ipAddress
     */
    public void setLocalIpAddress(String ipAddress)
    {
        this.localIpAddress = ipAddress;
    }

    /**
     * @return local ip port
     */
    public String getLocalIpPort()
    {
        return localIpPort;
    }

    /**
     * Set loca ip port
     * 
     * @param ipPort
     */
    public void setLocalIpPort(String ipPort)
    {
        this.localIpPort = ipPort;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.horstmann.violet.framework.network.config.IHostNetworkConfig#getLocalURL()
     */
    public URL getLocalURL()
    {
        try
        {
            URL url = new URL("http://" + getLocalIpAddress() + ":" + getLocalIpPort() + "/");
            return url;
        }
        catch (MalformedURLException e)
        {
            throw new RuntimeException("Error while building local network URL", e);
        }
    }

    /* (non-Javadoc)
     * @see java.lang.Object#clone()
     */
    public Object clone() throws CloneNotSupportedException
    {
        HTTPHostConfig clone = new HTTPHostConfig();
        String emptyString = "";
        if (this.userID != null) clone.userID = this.userID + emptyString;
        if (this.localIpAddress != null) clone.localIpAddress = this.localIpAddress + emptyString;
        if (this.localIpPort != null) clone.localIpPort = this.localIpPort + emptyString;
        return clone;
    }

    /**
     * Localhost user id
     */
    private String userID;

    /**
     * Local ip port
     */
    private String localIpPort;

    /**
     * Local ip address
     */
    private String localIpAddress;

}
