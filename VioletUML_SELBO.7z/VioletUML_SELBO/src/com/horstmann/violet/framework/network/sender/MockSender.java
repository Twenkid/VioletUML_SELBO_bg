package com.horstmann.violet.framework.network.sender;

import com.horstmann.violet.framework.network.NetworkMessage;

/**
 * Mock sender to simulate to real sender in a fake network sessuin
 * 
 * @author a.depellegrin
 * 
 */
public class MockSender implements ISender
{

    /**
     * @see com.horstmann.violet.framework.network.sender.ISender#sendMessage(com.horstmann.violet.framework.network.NetworkMessage)
     */
    public void sendMessage(NetworkMessage msg)
    {
        // Nothing to do
    }

}
