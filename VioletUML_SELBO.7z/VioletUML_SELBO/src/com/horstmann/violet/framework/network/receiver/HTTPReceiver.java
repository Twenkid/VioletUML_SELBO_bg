package com.horstmann.violet.framework.network.receiver;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.EventListener;

import javax.swing.event.EventListenerList;

import com.horstmann.violet.framework.diagram.GraphService;
import com.horstmann.violet.framework.network.NetworkMessage;

/**
 * 
 * @author Victor Freches
 * 
 */
public class HTTPReceiver implements IReceiver
{

    public HTTPReceiver(URL receiverURL)
    {
        this.url = receiverURL;
        this.listeners = new EventListenerList();
    }

    public void performReceivedMessage(String message)
    {
        try
        {
            NetworkMessage msg = this.getNetworkMessage(message);
            fireEvent(msg);
        }
        catch (IOException e)
        {
            // Well, we tried...
        }
    }

    public void addReceptionListener(IReceiverListener listener)
    {
        this.listeners.add(IReceiverListener.class, listener);

    }

    public void removeAllListener()
    {
        EventListener[] l = this.listeners.getListeners(IReceiverListener.class);
        for (int i = 0; i < l.length; i++)
        {
            this.listeners.remove(IReceiverListener.class, (IReceiverListener) l[i]);
        }
    }

    public void removeListener(IReceiverListener listener)
    {
        this.listeners.remove(IReceiverListener.class, listener);

    }

    public IReceiverListener[] getReceptionListeners()
    {
        return (IReceiverListener[]) this.listeners.getListeners(IReceiverListener.class);
    }

    public boolean hasNoListener()
    {
        if (this.listeners.getListenerCount() == 0)
        {
            return true;
        }
        return false;
    }

    private void fireEvent(NetworkMessage msg)
    {
        IReceiverListener[] listeners = getReceptionListeners();
        for (int i = 0; i < listeners.length; i++)
        {
            listeners[0].messageReceived(msg);
        }
    }

    private NetworkMessage getNetworkMessage(String message) throws IOException
    {
        ByteArrayInputStream bis = new ByteArrayInputStream(message.getBytes());
        NetworkMessage msg = GraphService.readNetworkMessage(bis);
        return msg;
    }

    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.network.receiver.IReceiver#getURL()
     */
    public URL getURL()
    {
        return this.url;
    }

    private EventListenerList listeners;
    private URL url;
}
