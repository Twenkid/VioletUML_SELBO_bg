package com.horstmann.violet.framework.network.config;

import java.net.MalformedURLException;
import java.net.URL;

import com.horstmann.violet.framework.network.NetworkConstant;
import com.horstmann.violet.framework.preference.PreferencesConstant;
import com.horstmann.violet.framework.preference.PreferencesService;
import com.horstmann.violet.framework.preference.PreferencesServiceFactory;

/**
 * HTTP implementation for guest network config
 * 
 * @author Alexandre de Pellegrin
 * 
 */
public class HTTPGuestConfig implements IGuestNetworkConfig
{

    /**
     * Default constructor
     */
    public HTTPGuestConfig()
    {
    }


    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.network.config.INetworkConfig#loadPreferedValues()
     */
    public void loadPreferedValues()
    {
        PreferencesService preferencesService = PreferencesServiceFactory.getInstance();
        String userID = preferencesService.get(PreferencesConstant.NETWORK_GUESTCONFIG_USERID, NetworkConstant.DEFAULT_USER_ID);
        String localURL = preferencesService.get(PreferencesConstant.NETWORK_GUESTCONFIG_HTTP_LOCALURL, NetworkConstant.DEFAULT_HTTP_LOCAL_URL
                .toString());
        this.setUserID(userID);
        try
        {
            URL url = new URL(localURL);
            this.setLocalIpAddress(url.getHost());
            this.setLocalIpPort(url.getPort() + "");
        }
        catch (MalformedURLException e)
        {
            this.setLocalIpPort(NetworkConstant.DEFAULT_HTTP_PORT);
        }
        String serverURL = preferencesService.get(PreferencesConstant.NETWORK_GUESTCONFIG_HTTP_SERVERURL, null);
        try
        {
            URL url = new URL(serverURL);
            this.setServerIpAddress(url.getHost());
            this.setServerIpPort(url.getPort() + "");
        }
        catch (MalformedURLException e1)
        {
            this.setServerIpPort(NetworkConstant.DEFAULT_HTTP_PORT);
        }
    }


    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.network.config.INetworkConfig#savePreferedValues()
     */
    public void savePreferedValues()
    {
        PreferencesService preferencesService = PreferencesServiceFactory.getInstance();
        preferencesService.put(PreferencesConstant.NETWORK_GUESTCONFIG_USERID, this.getUserID());
        preferencesService.put(PreferencesConstant.NETWORK_GUESTCONFIG_HTTP_LOCALURL, this.getLocalURL().toString());
        preferencesService.put(PreferencesConstant.NETWORK_GUESTCONFIG_HTTP_SERVERURL, this.getServerURL().toString());
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.horstmann.violet.framework.network.config.IGuestNetworkConfig#getUserID()
     */
    public String getUserID()
    {
        return userID;
    }

    /**
     * Set user id
     * 
     * @param userID
     */
    public void setUserID(String userID)
    {
        this.userID = userID;
    }

    /**
     * @return local ip address
     */
    public String getLocalIpAddress()
    {
        return localIpAddress;
    }

    /**
     * Set local ip address
     * 
     * @param ipAddress
     */
    public void setLocalIpAddress(String ipAddress)
    {
        this.localIpAddress = ipAddress;
    }

    /**
     * @return local ip port
     */
    public String getLocalIpPort()
    {
        return localIpPort;
    }

    /**
     * Set loca ip port
     * 
     * @param ipPort
     */
    public void setLocalIpPort(String ipPort)
    {
        this.localIpPort = ipPort;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.horstmann.violet.framework.network.config.IGuestNetworkConfig#getLocalURL()
     */
    public URL getLocalURL()
    {
        try
        {
            URL url = new URL("http://" + getLocalIpAddress() + ":" + getLocalIpPort() + "/");
            return url;
        }
        catch (MalformedURLException e)
        {
            throw new RuntimeException("Error while building local network URL", e);
        }
    }

    /**
     * @return remote server ip address
     */
    public String getServerIpAddress()
    {
        return serverIpAddress;
    }

    /**
     * Set remote server ip address
     * 
     * @param serverIpAddress
     */
    public void setServerIpAddress(String serverIpAddress)
    {
        this.serverIpAddress = serverIpAddress;
    }

    /**
     * @return remote server ip port
     */
    public String getServerIpPort()
    {
        return serverIpPort;
    }

    /**
     * Set remote server ip port
     * 
     * @param serverPort
     */
    public void setServerIpPort(String serverPort)
    {
        this.serverIpPort = serverPort;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.horstmann.violet.framework.network.config.IGuestNetworkConfig#getServerURL()
     */
    public URL getServerURL()
    {
        try
        {
            URL url = new URL("http://" + getServerIpAddress() + ":" + getServerIpPort() + "/");
            return url;
        }
        catch (MalformedURLException e)
        {
            throw new RuntimeException("Error while building server network URL", e);
        }
    }

    /* (non-Javadoc)
     * @see java.lang.Object#clone()
     */
    public Object clone() throws CloneNotSupportedException
    {
        HTTPGuestConfig clone = new HTTPGuestConfig();
        String emptyString = "";
        if (this.userID != null) clone.userID = this.userID + emptyString;
        if (this.localIpAddress != null) clone.localIpAddress = this.localIpAddress + emptyString;
        if (this.localIpPort != null) clone.localIpPort = this.localIpPort + emptyString;
        if (this.serverIpAddress != null) clone.serverIpAddress = this.localIpAddress + emptyString;
        if (this.serverIpPort != null) clone.serverIpPort = this.serverIpPort + emptyString;
        return clone;
    }

    /**
     * Localhost user id
     */
    private String userID;

    /**
     * Local ip port
     */
    private String localIpPort;

    /**
     * Local ip address
     */
    private String localIpAddress;

    /**
     * Remote server ip address
     */
    private String serverIpAddress;

    /**
     * Remote server ip port
     */
    private String serverIpPort = NetworkConstant.DEFAULT_HTTP_PORT;

}
