package com.horstmann.violet.framework.network.receiver;

import java.net.URL;



/**
 * 
 * @author Victor Freches
 *
 */
public interface IReceiver {

	public void addReceptionListener(IReceiverListener listener);
	public void removeAllListener();
	public void removeListener(IReceiverListener listener);
    public boolean hasNoListener();
    public URL getURL();
}
