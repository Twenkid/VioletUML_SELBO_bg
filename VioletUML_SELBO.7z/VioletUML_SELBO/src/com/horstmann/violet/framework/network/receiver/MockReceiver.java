package com.horstmann.violet.framework.network.receiver;

import java.net.URL;

/**
 * Mock receiver to simulate to real receiver in sending session or fake session. (A sending session is a network session only used
 * to send messages and never to receive ones. A fake session never sends or receive any message).
 * 
 * @author a.depellegrin
 * 
 */
public class MockReceiver implements IReceiver
{

    /**
     * Default constructor
     * @param url
     */
    public MockReceiver(URL url) {
        this.url = url;
    }
    
    /**
     * @see com.horstmann.violet.framework.network.receiver.IReceiver#addReceptionListener(com.horstmann.violet.framework.network.receiver.IReceiverListener)
     */
    public void addReceptionListener(IReceiverListener listener)
    {
        // Nothing to do
    }

    /**
     * @see com.horstmann.violet.framework.network.receiver.IReceiver#removeAllListener()
     */
    public void removeAllListener()
    {
        // Nothing to do
    }

    /**
     * @see com.horstmann.violet.framework.network.receiver.IReceiver#removeListener(com.horstmann.violet.framework.network.receiver.IReceiverListener)
     */
    public void removeListener(IReceiverListener listener)
    {
        // Nothing to do
    }

    /**
     * @see com.horstmann.violet.framework.network.receiver.IReceiver#hasNoListener()
     */
    public boolean hasNoListener()
    {
        return true;
    }

    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.network.receiver.IReceiver#getURL()
     */
    public URL getURL()
    {
        return this.url;
    }
    
    /**
     * Receiver url
     */
    private URL url;

}
