package com.horstmann.violet.framework.network.config;

import java.net.URL;

public interface NetworkConfig
{
    public String getUserID();
    
    public URL getLocalURL();
    

}
