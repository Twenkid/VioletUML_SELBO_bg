package com.horstmann.violet.framework.network;

public class NetworkMessageSubjectType
{
    public static final NetworkMessageSubjectType NODE_ADDED = new NetworkMessageSubjectType("subject00: node added on diagram {0}");
    public static final NetworkMessageSubjectType NODE_UPDATED = new NetworkMessageSubjectType("subject01: node updated on diagram {0}");
    public static final NetworkMessageSubjectType NODE_DELETED = new NetworkMessageSubjectType("subject02: node deleted on diagram {0}");
    public static final NetworkMessageSubjectType NODE_ATTACHED = new NetworkMessageSubjectType("subject03: node attached on node {0} (diagram {1})");
    public static final NetworkMessageSubjectType NODE_DETACHED = new NetworkMessageSubjectType("subject04: node {0} detached from node {1} (diagram {2})");
    public static final NetworkMessageSubjectType EDGE_ADDED = new NetworkMessageSubjectType("subject05: edge added on diagram {0}");
    public static final NetworkMessageSubjectType EDGE_UPDATED = new NetworkMessageSubjectType("subject06: edge updated on diagram {0}");
    public static final NetworkMessageSubjectType EDGE_DELETED = new NetworkMessageSubjectType("subject07: edge deleted on diagram {0}");
    public static final NetworkMessageSubjectType REQUEST_GRAPH_REFRESH = new NetworkMessageSubjectType("subject08: please, send me diagram {0}");
    public static final NetworkMessageSubjectType GRAPH_UPDATED = new NetworkMessageSubjectType("subject09: here is diagram {0} content");
    public static final NetworkMessageSubjectType DISCONNECT_CLIENT = new NetworkMessageSubjectType("subject10: please, disconnect me fron diagram {0} session");
    public static final NetworkMessageSubjectType REQUEST_SHARED_DIAGRAMS_LIST = new NetworkMessageSubjectType("subject11: please, send me your diagram list");
    public static final NetworkMessageSubjectType SHARED_DIAGRAMS_LIST = new NetworkMessageSubjectType("subject12: here is my diagram list");
    public static final NetworkMessageSubjectType UNDEFINED = new NetworkMessageSubjectType("");
    public static final NetworkMessageSubjectType[] TYPE_LIST = new NetworkMessageSubjectType[]
    {
            NODE_ADDED,
            NODE_UPDATED,
            NODE_DELETED,
            NODE_ATTACHED,
            NODE_DETACHED,
            EDGE_ADDED,
            EDGE_UPDATED,
            EDGE_DELETED,
            REQUEST_GRAPH_REFRESH,
            GRAPH_UPDATED,
            DISCONNECT_CLIENT,
            REQUEST_SHARED_DIAGRAMS_LIST,
            SHARED_DIAGRAMS_LIST,
            UNDEFINED
    };
    
    private NetworkMessageSubjectType(String pattern) {
        this.pattern = pattern;
    }
    
    
    public String getPattern()
    {
        return this.pattern;
    }
    
    public static NetworkMessageSubjectType parseType(String subject) {
        if (subject.length() > 9) {
            String indexStr = subject.substring(7,9);
            int index = Integer.parseInt(indexStr);
            return TYPE_LIST[index];
        }
        return UNDEFINED;
    }
    
    private String pattern;
}
