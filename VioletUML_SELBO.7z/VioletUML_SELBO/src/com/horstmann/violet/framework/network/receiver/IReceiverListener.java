package com.horstmann.violet.framework.network.receiver;

import java.util.EventListener;

import com.horstmann.violet.framework.network.NetworkMessage;

/**
 * 
 * @author Victor Freches
 * 
 */
public interface IReceiverListener extends EventListener
{
    public abstract void messageReceived(NetworkMessage msg);
}
