package com.horstmann.violet.framework.network;

public interface NetworkMessageSubjectConstant
{
    public static final String NODE_ADDED = "subject:nodeAdded";
    public static final String NODE_UPDATED = "subject:nodeUpdated";
    public static final String NODE_DELETED = "subject:nodeDeleted";
    public static final String EDGE_ADDED = "subject:edgeAdded";
    public static final String EDGE_UPDATED = "subject:edgeUpdated";
    public static final String EDGE_DELETED = "subject:edgeDeleted";
    public static final String GRAPH_REFRESH_REQUESTED = "subject:requestGraph";
    public static final String GRAPH_UPDATED ="subject:graph";
    public static final String CLOSE_SESSION = "subject:disconnectClient";
    public static final String REQUEST_SHARED_DIAGRAMS_LIST = "subject:requestSharedDiagramsList";
    public static final String SHARED_DIAGRAMS_LIST = "subject:sharedDiagramsList";
    
}
