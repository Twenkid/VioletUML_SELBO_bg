package com.horstmann.violet.framework.network.sender;

import com.horstmann.violet.framework.network.NetworkMessage;
/**
 * A sender is made to send messages to recipients
 * 
 * @author Victor Freches
 */
public interface ISender {
	
	/**
     * Sends a message
	 * @param msg m
	 */
	public abstract void sendMessage(NetworkMessage msg);

}
