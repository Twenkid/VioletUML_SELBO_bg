package com.horstmann.violet.framework.network;

import java.awt.geom.Point2D;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import com.horstmann.violet.framework.diagram.Edge;
import com.horstmann.violet.framework.diagram.Graph;
import com.horstmann.violet.framework.diagram.Node;
import com.horstmann.violet.framework.gui.DiagramPanel;
import com.horstmann.violet.framework.gui.DialogFactory;
import com.horstmann.violet.framework.gui.GraphPanel;
import com.horstmann.violet.framework.gui.PropertySheet;
import com.horstmann.violet.framework.network.config.HTTPGuestConfig;
import com.horstmann.violet.framework.network.config.HTTPHostConfig;
import com.horstmann.violet.framework.network.config.IGuestNetworkConfig;
import com.horstmann.violet.framework.network.config.IHostNetworkConfig;
import com.horstmann.violet.framework.network.config.INetworkConfig;
import com.horstmann.violet.framework.resources.ResourceBundleConstant;
import com.horstmann.violet.framework.util.PropertyUtils;

public class NetworkAction
{

    public NetworkAction()
    {
        this.resourceBundle = ResourceBundle.getBundle(ResourceBundleConstant.NETWORK_STRINGS, Locale.getDefault());
    }

    public void shareDiagramPanel(DiagramPanel dPanel)
    {
        IHostNetworkConfig config = getHostNetworkConfig();
        boolean isValidated = editConfig(config);
        if (!isValidated)
        {
            return;
        }
        NetworkManager networkManager = getNetworkManager();
        NetworkSession session = networkManager.getStandardSession(config.getUserID(), config.getLocalURL());
        networkManager.attachDiagramToSession(dPanel, session);
    }
    

    /**
     * Edits a network config and return true to validate new config or false to cancel
     * 
     * @param config to edit
     * @return true to validate new properties or false if not
     */
    private boolean editConfig(INetworkConfig networkConfig)
    {
        Object backup = null;
        try
        {
            backup = networkConfig.clone();
        }
        catch (CloneNotSupportedException e)
        {
            // Well, we tried
        }
        
        PropertySheet sheet = new PropertySheet(networkConfig);
        JOptionPane optionPane = new JOptionPane();
        optionPane.setOpaque(false);
        optionPane.setMessage(sheet.getComponent());
        optionPane.setOptionType(JOptionPane.OK_CANCEL_OPTION);
        DialogFactory.getInstance().showDialog(optionPane, this.resourceBundle.getString("dialog.network_config.title"), true);
        int result = JOptionPane.CANCEL_OPTION;
        if (!JOptionPane.UNINITIALIZED_VALUE.equals(optionPane.getValue()))
        {
            result = ((Integer) optionPane.getValue()).intValue();
        }
        if (result == JOptionPane.YES_OPTION)
        {
            networkConfig.savePreferedValues();
            return true;
        }
        PropertyUtils.copyProperties(backup, networkConfig);
        return false;
    }
    
    
    

    public void openRemoteDiagram()
    {
        IGuestNetworkConfig config = getGuestNetworkConfig();
        boolean isValidated = editConfig(config);
        if (!isValidated)
        {
            return;
        }
        NetworkManager networkManager = getNetworkManager();
        NetworkSession session = networkManager.getStandardSession(config.getUserID(), config.getLocalURL());
        networkManager.sendMessageToRecipient(session, NetworkMessageSubjectType.REQUEST_SHARED_DIAGRAMS_LIST, "", config.getServerURL());
        config.savePreferedValues();
    }

    public void selectDiagramFromList(SortedMap<String, String> sharedDiagramsList, String senderID, URL senderURL)
    {
        Set<String> diagramIds = sharedDiagramsList.keySet();
        List<String> titles = new ArrayList<String>();
        for (String id : diagramIds) {
            String aTitle = sharedDiagramsList.get(id).toString();
            titles.add(aTitle);
        }
        String[] titleArray = (String[]) titles.toArray(new String[titles.size()]);
        JList list = new JList(titleArray);
        list.setOpaque(true);
        JPanel panel = new JPanel();
        panel.add(list);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.getViewport().add(list);
        scrollPane.setSize(300, 400);
        JOptionPane optionPane = new JOptionPane();
        optionPane.setMessage(scrollPane);
        optionPane.setOptionType(JOptionPane.OK_CANCEL_OPTION);
        optionPane.setOpaque(false);
        DialogFactory.getInstance().showDialog(optionPane, "Select a diagram", true);
        int result = JOptionPane.CANCEL_OPTION;
        if (!JOptionPane.UNINITIALIZED_VALUE.equals(optionPane.getValue()))
        {
            result = ((Integer) optionPane.getValue()).intValue();
        }
        if (result == JOptionPane.OK_OPTION)
        {
            int index = list.getSelectedIndex();
            if (index == -1)
            {
                return;
            }
            String[] ids = (String[]) diagramIds.toArray(new String[diagramIds.size()]);
            String selectedId = ids[index];
            DiagramPanel diagramPanel = new DiagramPanel(selectedId);
            diagramPanel.setTitle("Waiting for remote diagram...");
            NetworkManager networkManager = getNetworkManager();
            networkManager.registerNewDiagramPanel(diagramPanel);
            IGuestNetworkConfig config = getGuestNetworkConfig();
            NetworkSession session = networkManager.getStandardSession(config.getUserID(), config.getLocalURL());
            session.addRecipient(senderID, senderURL); // Registers server as new recipient for further messages
            networkManager.attachDiagramToSession(diagramPanel, session);
            networkManager.sendMessageToRecipient(session, NetworkMessageSubjectType.REQUEST_GRAPH_REFRESH, selectedId, senderURL);
        }
    }

    public void sendSharedDiagramsList(URL senderURL)
    {
        NetworkManager manager = getNetworkManager();
        DiagramPanel[] sharedDiagramPanels = manager.getSharedDiagramPanels();
        SortedMap<String, String> sharedDiagramsList = new TreeMap<String, String>();
        for (int i = 0; i < sharedDiagramPanels.length; i++)
        {
            DiagramPanel aPanel = sharedDiagramPanels[i];
            sharedDiagramsList.put(aPanel.getId(), aPanel.getTitle());
        }
        IHostNetworkConfig config = getHostNetworkConfig();
        final NetworkSession sendingSession = manager.getSendingOnlySession(config.getUserID(), config.getLocalURL());
        manager.sendMessageToRecipient(sendingSession, NetworkMessageSubjectType.SHARED_DIAGRAMS_LIST,
                sharedDiagramsList, senderURL);
    }



    public void receiveNewNode(NetworkSession session, Node newNode, URL senderURL)
    {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        double posX = newNode.getBounds().getX();
        double posY = newNode.getBounds().getY();
        Point2D location = new Point2D.Double(posX, posY);
        if (graph.findNode(newNode.getId()) == null)
        {
            graphPanel.addNodeAtPoint(newNode, location);
            graphPanel.repaint();
            // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.NODE_ADDED, newNode, senderURL);
        }
    }

    public void receiveDeletedNode(NetworkSession session, Node removedNode, URL senderURL)
    {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        Node localNodeToDelete = graph.findNode(removedNode.getId());
        if (localNodeToDelete != null)
        {
            graphPanel.removeNode(localNodeToDelete);
            graphPanel.repaint();
            // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.NODE_DELETED, removedNode, senderURL);
        }
    }

    public void receiveUpdatedNode(NetworkSession session, Node updatedNode, URL senderURL)
    {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        Node localNodeToUpdate = graph.findNode(updatedNode.getId());
        if (localNodeToUpdate != null)
        { // If node found, just updates it
            if (updatedNode.getRevision().intValue() <= localNodeToUpdate.getRevision().intValue()) {
                // updated node is up to date!
                return;
            }
            graphPanel.updateNode(updatedNode, localNodeToUpdate);
            graphPanel.repaint();
            // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.NODE_UPDATED, updatedNode, senderURL);
        }
        if (localNodeToUpdate == null)
        { // If node not found, adds it
            double posX = updatedNode.getBounds().getX();
            double posY = updatedNode.getBounds().getY();
            Point2D location = new Point2D.Double(posX, posY);
            graphPanel.addNodeAtPoint(updatedNode, location);
            graphPanel.repaint();
            // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.NODE_UPDATED, updatedNode, senderURL);
        }
    }
    
    public void receiveAttachedNode(NetworkSession session, String parentNodeId, Node childNode) {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        Node parentNode = graph.findNode(parentNodeId);
        if (parentNode == null) return;
        final Node localNodeToAttach = graph.findNode(childNode.getId());
        if (localNodeToAttach == null) {
            double posX = childNode.getBounds().getX();
            double posY = childNode.getBounds().getY();
            Point2D location = new Point2D.Double(posX, posY);
            parentNode.checkAddNode(childNode, location);
            graphPanel.repaint();
        }
        if (localNodeToAttach != null) {
            double posX = localNodeToAttach.getBounds().getX();
            double posY = localNodeToAttach.getBounds().getY();
            Point2D location = new Point2D.Double(posX, posY);
            parentNode.checkAddNode(localNodeToAttach, location);
            graphPanel.repaint();
        }
    }
    
    public void receiveDetachedNode(NetworkSession session, String parentNodeId, String childNodeId) {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        Node parentNode = graph.findNode(parentNodeId);
        final Node localNodeToDetach = graph.findNode(childNodeId);
        if (parentNode == null || localNodeToDetach == null) return;
        parentNode.checkRemoveNode(localNodeToDetach);
        graphPanel.repaint();
    }    

    public void receiveNewEdge(NetworkSession session, Edge newEdge, URL senderURL)
    {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        if (graph.findEdge(newEdge.getId()) == null)
        {
            String startNodeId = newEdge.getStart().getId();
            String endNodeId = newEdge.getEnd().getId();
            Node startNode = graph.findNode(startNodeId);
            Node endNode = graph.findNode(endNodeId);
            if (startNode != null && endNode != null)
            {
                double startPosX = startNode.getBounds().getX();
                double startPosY = startNode.getBounds().getY();
                double endPosX = endNode.getBounds().getX();
                double endPosY = endNode.getBounds().getY();
                Point2D startPoint = new Point2D.Double(startPosX, startPosY);
                Point2D endPoint = new Point2D.Double(endPosX, endPosY);
                graphPanel.addEdgeAtPoints(newEdge, startPoint, endPoint);
                graphPanel.repaint();
                // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.EDGE_ADDED, newEdge, senderURL);
            }
        }
    }

    public void receiveUpdatedEdge(NetworkSession session, Edge updatedEdge, URL senderURL)
    {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        Edge localEdgeToUpdate = graph.findEdge(updatedEdge.getId());
        if (localEdgeToUpdate != null)
        { // if edge found, just updates it
            if (updatedEdge.getRevision().intValue() <= localEdgeToUpdate.getRevision().intValue()) {
                // updated edge is up to date!
                return;
            }
            graphPanel.updateEdge(updatedEdge, localEdgeToUpdate);
            graphPanel.repaint();
            // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.EDGE_UPDATED, updatedEdge, senderURL);
        }
        if (localEdgeToUpdate == null)
        { // if not found, adds it to graph
            String startNodeId = updatedEdge.getStart().getId();
            String endNodeId = updatedEdge.getEnd().getId();
            Node startNode = graph.findNode(startNodeId);
            Node endNode = graph.findNode(endNodeId);
            if (startNode != null && endNode != null)
            {
                double startPosX = startNode.getBounds().getX();
                double startPosY = startNode.getBounds().getY();
                double endPosX = endNode.getBounds().getX();
                double endPosY = endNode.getBounds().getY();
                Point2D startPoint = new Point2D.Double(startPosX, startPosY);
                Point2D endPoint = new Point2D.Double(endPosX, endPosY);
                graphPanel.addEdgeAtPoints(updatedEdge, startPoint, endPoint);
                graphPanel.repaint();
                // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.EDGE_UPDATED, updatedEdge, senderURL);
            }
        }
    }

    public void receiveDeletedEdge(NetworkSession session, Edge deletedEdge, URL senderURL)
    {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        GraphPanel graphPanel = sharedDiagramPanel.getGraphPanel();
        Graph graph = graphPanel.getGraph();
        Edge localEdgeToDelete = graph.findEdge(deletedEdge.getId());
        if (localEdgeToDelete != null)
        {
            graphPanel.removeEdge(localEdgeToDelete);
            graphPanel.repaint();
            // networkManager.sendMessageToAllExceptRecipient(session, NetworkMessageSubjectType.EDGE_DELETED, deletedEdge, senderURL);
        }
    }

    public void receiveUpdatedGraph(NetworkSession session, Graph updatedGraph)
    {
        NetworkManager networkManager = getNetworkManager();
        DiagramPanel sharedDiagramPanel = networkManager.getAttachedDiagram(session);
        sharedDiagramPanel.setGraph(updatedGraph);
    }

    public void requestGraphRefresh(String sharedDiagramPanelId)
    {
        NetworkSession session = getNetworkManager().getNetworkSession(sharedDiagramPanelId);
        getNetworkManager().sendMessageToAll(session, NetworkMessageSubjectType.REQUEST_GRAPH_REFRESH, "");
    }

   
    public void sendGraph(NetworkSession session, URL recipientURL, Graph graph)
    {
        getNetworkManager().sendMessageToRecipient(session, NetworkMessageSubjectType.GRAPH_UPDATED, graph, recipientURL);
    }

    public void sendAddedNode(DiagramPanel shareDiagramPanel, Node node)
    {
        NetworkSession session = getNetworkManager().getNetworkSession(shareDiagramPanel.getId());
        if (session != null) {
            getNetworkManager().sendMessageToAll(session, NetworkMessageSubjectType.NODE_ADDED, node);
        }
    }

    public void sendModifiedNode(DiagramPanel shareDiagramPanel, Node node)
    {
        NetworkSession session = getNetworkManager().getNetworkSession(shareDiagramPanel.getId());
        if (session != null) {
            getNetworkManager().sendMessageToAll(session, NetworkMessageSubjectType.NODE_UPDATED, node);
        }
    }

    public void sendRemovedNode(DiagramPanel shareDiagramPanel, Node node)
    {
        NetworkSession session = getNetworkManager().getNetworkSession(shareDiagramPanel.getId());
        if (session != null) {
            getNetworkManager().sendMessageToAll(session, NetworkMessageSubjectType.NODE_DELETED, node);
        }
    }

    public void sendAddedEdge(DiagramPanel shareDiagramPanel, Edge edge)
    {
        NetworkSession session = getNetworkManager().getNetworkSession(shareDiagramPanel.getId());
        if (session != null) {
            getNetworkManager().sendMessageToAll(session, NetworkMessageSubjectType.EDGE_ADDED, edge);
        }
    }

    public void sendModifiedEdge(DiagramPanel shareDiagramPanel, Edge edge)
    {
        NetworkSession session = getNetworkManager().getNetworkSession(shareDiagramPanel.getId());
        if (session != null) {
            getNetworkManager().sendMessageToAll(session, NetworkMessageSubjectType.EDGE_UPDATED, edge);
        }
    }

    public void sendRemovedEdge(DiagramPanel shareDiagramPanel, Edge edge)
    {
        NetworkSession session = getNetworkManager().getNetworkSession(shareDiagramPanel.getId());
        if (session != null) {
            getNetworkManager().sendMessageToAll(session, NetworkMessageSubjectType.EDGE_DELETED, edge);
        }
    }

    private NetworkManager getNetworkManager()
    {
        return NetworkManager.getInstance();
    }

    private IHostNetworkConfig getHostNetworkConfig() {
        if (this.hostNetworkConfig == null) {
            this.hostNetworkConfig = new HTTPHostConfig();
            this.hostNetworkConfig.loadPreferedValues();

        }
        return this.hostNetworkConfig;
    }
    
    private IGuestNetworkConfig getGuestNetworkConfig() {
        if (this.guestNetworkConfig == null) {
            this.guestNetworkConfig = new HTTPGuestConfig();
            this.guestNetworkConfig.loadPreferedValues();
        }
        return this.guestNetworkConfig;
    }
    
    
    /**
     * Network external resources.
     */
    private ResourceBundle resourceBundle;
    
    private IHostNetworkConfig hostNetworkConfig;
    
    private IGuestNetworkConfig guestNetworkConfig;


}
