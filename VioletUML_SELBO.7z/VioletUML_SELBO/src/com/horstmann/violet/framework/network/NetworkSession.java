package com.horstmann.violet.framework.network;

import java.net.URL;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.horstmann.violet.framework.network.receiver.IReceiver;
import com.horstmann.violet.framework.network.sender.ISender;

/**
 * This class represents a session shared between different persons on the network
 * 
 * @author Victor Freches
 * 
 */
public class NetworkSession
{

    public NetworkSession(String senderID, IReceiver receiver, ISender sender)
    {
        this.senderID = senderID;
        this.recipients = new HashMap<String, URL>();
        this.receiver = receiver;
        this.sender = sender;
    }

    


    /**
     * Adds a new recipient to this session. Sender could not be added as recipient to avoid loopback.
     * 
     * @param recipientID
     * @param recipientURL
     */
    public void addRecipient(String recipientID, URL recipientURL)
    {
        final URL localURL = this.getReceiver().getURL();
        if (!recipients.containsKey(recipientID) && !recipientURL.equals(localURL))
        {
            recipients.put(recipientID, recipientURL);
        }
    }

    /**
     * Removes a recipient
     * 
     * @param recipientID
     */
    public void removeRecipient(String recipientID)
    {
        recipients.remove(recipientID);
    }

    public String getSenderID()
    {
        return senderID;
    }


    public URL[] getRecipients()
    {
        Collection<URL> r = this.recipients.values();
        URL[] result = r.toArray(new URL[r.size()]);
        return result;
    }

    public URL getRecipient(String userID)
    {
        URL recipientURL = (URL) this.recipients.get(userID);
        return recipientURL;
    }
    
    public IReceiver getReceiver() {
        return this.receiver;
    }
    
    public ISender getSender() {
        return this.sender;
    }
    
    public String toString()
    {
        final URL localURL = receiver.getURL();
        return localURL.toString();
    }

    private String senderID;

    private Map<String, URL> recipients;
    
    private IReceiver receiver;
    
    private ISender sender;

}
