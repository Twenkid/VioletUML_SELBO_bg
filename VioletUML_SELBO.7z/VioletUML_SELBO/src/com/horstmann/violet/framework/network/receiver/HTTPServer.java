package com.horstmann.violet.framework.network.receiver;

import java.io.IOException;
import java.util.Properties;

import com.horstmann.violet.framework.network.NetworkConstant;
import com.horstmann.violet.framework.util.NanoHTTPD;

public class HTTPServer extends NanoHTTPD
{

    public HTTPServer(HTTPReceiver receiver, int port) throws IOException
    {
        super(port);
        System.out.println("HTTP server started on port " + port);
        this.receiver = receiver;
    }

    public Response serve(String uri, String method, Properties header, Properties parms)
    {
        if (NetworkConstant.HTTP_CONTEXT_URI.equals(uri)) {
            if (parms.containsKey(NetworkConstant.HTTP_POSTED_INPUT_FIELD_NAME)) {
                String message = parms.getProperty(NetworkConstant.HTTP_POSTED_INPUT_FIELD_NAME);
                this.receiver.performReceivedMessage(message);
            }
        }
        return super.serve(uri, method, header, parms);
    }
    
    public HTTPReceiver getReceiver() {
        return this.receiver;
    }
    
    private HTTPReceiver receiver;


}
