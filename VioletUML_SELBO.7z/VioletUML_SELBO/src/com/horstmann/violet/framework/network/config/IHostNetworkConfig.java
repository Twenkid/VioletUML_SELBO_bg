package com.horstmann.violet.framework.network.config;

import java.net.URL;

/**
 * Contains network config for a host session (all needed to allow clients to connect to this host, in other words)
 * 
 * @author Alexandre de Pellegrin
 *
 */
public interface IHostNetworkConfig extends INetworkConfig
{
    /**
     * @return user id
     */
    public String getUserID();
    
    /**
     * @return local url (we can suppose that this host has many urls)
     */
    public URL getLocalURL();
    

}
