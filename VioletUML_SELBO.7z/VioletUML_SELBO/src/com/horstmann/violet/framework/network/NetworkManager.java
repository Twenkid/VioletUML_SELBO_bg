package com.horstmann.violet.framework.network;

import java.net.URL;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

import javax.swing.event.EventListenerList;

import com.horstmann.violet.framework.diagram.Edge;
import com.horstmann.violet.framework.diagram.Graph;
import com.horstmann.violet.framework.diagram.Node;
import com.horstmann.violet.framework.gui.DiagramPanel;
import com.horstmann.violet.framework.network.receiver.IReceiver;
import com.horstmann.violet.framework.network.receiver.IReceiverListener;
import com.horstmann.violet.framework.network.receiver.MockReceiver;
import com.horstmann.violet.framework.network.receiver.ReceiverFactory;
import com.horstmann.violet.framework.network.sender.ISender;
import com.horstmann.violet.framework.network.sender.SenderFactory;

/**
 * Manages network sessions
 * 
 * @author Alexandre de Pellegrin
 * 
 */
public class NetworkManager
{

    /**
     * Default constructor
     */
    private NetworkManager()
    {

    }

    /**
     * @return singleton instance. Be carefull to avoid calling this method too often. Do not abuse of singletons!
     */
    public static NetworkManager getInstance()
    {
        if (NetworkManager.instance == null)
        {
            NetworkManager.instance = new NetworkManager();
        }
        return NetworkManager.instance;
    }

    /**
     * Gets a full duplex network session
     * 
     * @param userID local user id
     * @param localURL local URL
     * @return session
     */
    public NetworkSession getStandardSession(String userID, URL localURL)
    {
        ISender sender = getSender(localURL);
        IReceiver receiver = getReceiver(localURL);
        NetworkSession session = new NetworkSession(userID, receiver, sender);
        return session;
    }

    /**
     * Gets a 'sending only' network session
     * 
     * @param userID local user id
     * @param localURL local URL
     * @return session
     */
    public NetworkSession getSendingOnlySession(String userID, URL localURL)
    {
        ISender sender = getSender(localURL);
        IReceiver receiver = new MockReceiver(localURL);
        NetworkSession session = new NetworkSession(userID, receiver, sender);
        return session;
    }

    /**
     * @return network message sender
     */
    public ISender getSender(URL senderURL)
    {
        return SenderFactory.getInstance().createSender(senderURL);
    }

    /**
     * @return network message receiver
     */
    public IReceiver getReceiver(URL receiverURL)
    {
        IReceiver receiver = ReceiverFactory.getInstance().createReceiver(receiverURL);
        if (receiver.hasNoListener())
        {
            receiver.addReceptionListener(new IReceiverListener()
            {
                @SuppressWarnings("unchecked")
                public void messageReceived(NetworkMessage msg)
                {
                    String subject = msg.getSubject();
                    NetworkMessageSubjectType subjectType = NetworkMessageSubjectType.parseType(subject);
                    if (subjectType.equals(NetworkMessageSubjectType.UNDEFINED))
                    {
                        return;
                    }
                    String senderID = msg.getFrom();
                    URL senderURL = msg.getReplyAddress();
                    String[] subjectArguments = getMessageSubjectArguments(subject);
                    if (NetworkMessageSubjectType.REQUEST_SHARED_DIAGRAMS_LIST.equals(subjectType))
                    {
                        action.sendSharedDiagramsList(senderURL);

                    }
                    else if (NetworkMessageSubjectType.SHARED_DIAGRAMS_LIST.equals(subjectType))
                    {
                        SortedMap<String, String> sharedDiagramsList = (SortedMap<String, String>) msg.getContent();
                        action.selectDiagramFromList(sharedDiagramsList, senderID, senderURL);
                    }
                    else if (NetworkMessageSubjectType.REQUEST_GRAPH_REFRESH.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        DiagramPanel sharedDiagramPanel = getAttachedDiagram(session);
                        Graph graph = sharedDiagramPanel.getGraphPanel().getGraph();
                        session.addRecipient(senderID, senderURL); // Register new client
                        action.sendGraph(session, senderURL, graph);
                    }
                    else if (NetworkMessageSubjectType.NODE_ADDED.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Node newNode = (Node) msg.getContent();
                        action.receiveNewNode(session, newNode, senderURL);
                    }
                    else if (NetworkMessageSubjectType.NODE_DELETED.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Node remotelyDeletedNode = (Node) msg.getContent();
                        action.receiveDeletedNode(session, remotelyDeletedNode, senderURL);
                    }
                    else if (NetworkMessageSubjectType.NODE_UPDATED.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Node remotelyUpdatedNode = (Node) msg.getContent();
                        action.receiveUpdatedNode(session, remotelyUpdatedNode, senderURL);
                    }
                    else if (NetworkMessageSubjectType.NODE_ATTACHED.equals(subjectType))
                    {
                        if (subjectArguments.length < 2) return;
                        String parentNodeId = subjectArguments[0];
                        String sharedDiagramId = subjectArguments[1];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Node childNode = (Node) msg.getContent();
                        action.receiveAttachedNode(session, parentNodeId, childNode);
                    }
                    else if (NetworkMessageSubjectType.NODE_DETACHED.equals(subjectType))
                    {
                        if (subjectArguments.length < 3) return;
                        String childNodeId = subjectArguments[0];
                        String parentNodeId = subjectArguments[1];
                        String sharedDiagramId = subjectArguments[2];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        action.receiveDetachedNode(session, parentNodeId, childNodeId);
                    }                    
                    else if (NetworkMessageSubjectType.EDGE_ADDED.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Edge newEdge = (Edge) msg.getContent();
                        action.receiveNewEdge(session, newEdge, senderURL);
                    }
                    else if (NetworkMessageSubjectType.EDGE_UPDATED.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Edge remotelyUpdatedEdge = (Edge) msg.getContent();
                        action.receiveUpdatedEdge(session, remotelyUpdatedEdge, senderURL);
                    }
                    else if (NetworkMessageSubjectType.EDGE_DELETED.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Edge remotelyDeletedEdge = (Edge) msg.getContent();
                        action.receiveDeletedEdge(session, remotelyDeletedEdge, senderURL);
                    }
                    else if (NetworkMessageSubjectType.GRAPH_UPDATED.equals(subjectType))
                    {
                        if (subjectArguments.length < 1) return;
                        String sharedDiagramId = subjectArguments[0];
                        NetworkSession session = getNetworkSession(sharedDiagramId);
                        Graph g = (Graph) msg.getContent();
                        action.receiveUpdatedGraph(session, g);
                    }
                    else if (NetworkMessageSubjectType.DISCONNECT_CLIENT.equals(subjectType))
                    {

                    }
                }
            });
        }
        return receiver;
    }

    /**
     * Sends a message to a specific recipient
     * 
     * @param session network session ti use
     * @param subjectType subject type
     * @param clientID
     * @param content
     * @param recipientURL
     */
    public void sendMessageToRecipient(NetworkSession session, NetworkMessageSubjectType subjectType, Object content,
            URL recipientURL)
    {
        String subject = getPreparedMessageSubject(subjectType, session);
        String senderID = session.getSenderID();
        URL senderURL = session.getReceiver().getURL();
        ISender sender = session.getSender();
        NetworkMessage msg = new NetworkMessage(senderID, senderURL, subject, content);
        msg.addRecipient(recipientURL);
        sender.sendMessage(msg);
    }

    /**
     * Sends a message to all registered recipients
     * 
     * @param session network session to use
     * @param subjectType subject type
     * @param content
     */
    public void sendMessageToAll(NetworkSession session, NetworkMessageSubjectType subjectType, Object content)
    {
        String subject = getPreparedMessageSubject(subjectType, session);
        String senderID = session.getSenderID();
        URL senderURL = session.getReceiver().getURL();
        ISender sender = session.getSender();
        NetworkMessage msg = new NetworkMessage(senderID, senderURL, subject, content);
        URL[] recipientURLs = session.getRecipients();
        if (recipientURLs.length == 0) return;
        if (recipientURLs.length > 0)
        {
            for (int i = 0; i < recipientURLs.length; i++)
            {
                msg.addRecipient(recipientURLs[i]);
            }
            sender.sendMessage(msg);
        }
    }

    /**
     * Sends a message to all registered recipients
     * 
     * @param session network session to use
     * @param subjectType subject type
     * @param content
     * @param recipientURL to exclude from sending
     */
    public void sendMessageToAllExceptRecipient(NetworkSession session, NetworkMessageSubjectType subjectType, Object content,
            URL recipientURL)
    {
        String subject = getPreparedMessageSubject(subjectType, session);
        String senderID = session.getSenderID();
        URL senderURL = session.getReceiver().getURL();
        ISender sender = session.getSender();
        NetworkMessage msg = new NetworkMessage(senderID, senderURL, subject, content);
        URL[] recipientURLs = session.getRecipients();
        if (recipientURLs.length == 0) return;
        if (recipientURLs.length > 0)
        {
            for (int i = 0; i < recipientURLs.length; i++)
            {
                if (!recipientURLs[i].equals(recipientURL))
                {
                    msg.addRecipient(recipientURLs[i]);
                }
            }
            sender.sendMessage(msg);
        }
    }

    private String getPreparedMessageSubject(NetworkMessageSubjectType subjectType, NetworkSession session)
    {
        List<String> args = new ArrayList<String>();
        String pattern = subjectType.getPattern();
        DiagramPanel attachedDiagram = getAttachedDiagram(session);
        if (attachedDiagram != null)
        {
            args.add(attachedDiagram.getId());
        }
        return MessageFormat.format(pattern, args.toArray());
    }

    private String[] getMessageSubjectArguments(String subject)
    {
        List<String> arguments = new ArrayList<String>();
        NetworkMessageSubjectType subjectType = NetworkMessageSubjectType.parseType(subject);
        MessageFormat messageFormat = new MessageFormat(subjectType.getPattern());
        try
        {
            Object[] objects = messageFormat.parse(subject);
            for (int i = 0; i < objects.length; i++)
            {
                arguments.add(objects[i].toString());
            }
        }
        catch (ParseException e)
        {
            // Well... we tried
        }
        return (String[]) arguments.toArray(new String[arguments.size()]);
    }

    public synchronized void addListener(NetworkManagerListener l)
    {
        this.listeners.add(NetworkManagerListener.class, l);
    }

    public void registerNewDiagramPanel(DiagramPanel newDiagramPanel)
    {
        NetworkManagerListener[] listeners = this.listeners.getListeners(NetworkManagerListener.class);
        for (int i = 0; i < listeners.length; ++i)
        {
            NetworkManagerListener aListener = listeners[i];
            aListener.newDiagramPanelCreated(newDiagramPanel);
        }
    }

    /**
     * Returns the network session attached to this diagramId
     * 
     * @param sharedDiagramId
     * @return session
     */
    public NetworkSession getNetworkSession(String sharedDiagramId)
    {
        for (DiagramPanel aDiagramPanel : this.diagramToSessionMap.keySet())
        {
            if (aDiagramPanel.getId().equals(sharedDiagramId))
            {
                return (NetworkSession) this.diagramToSessionMap.get(aDiagramPanel);
            }
        }
        return null;
    }

    /**
     * Binds a diagram panel to a network session
     * 
     * @param dPanel
     * @param session
     */
    public void attachDiagramToSession(DiagramPanel dPanel, NetworkSession session)
    {
        if (this.diagramToSessionMap.containsKey(dPanel))
        {
            throw new RuntimeException("Diagram already atatched to a network session");
        }
        this.diagramToSessionMap.put(dPanel, session);
    }

    /**
     * Looks for a diagram panel attached to session and returns it
     * 
     * @param session
     * @return diagram panel
     */
    public DiagramPanel getAttachedDiagram(NetworkSession session)
    {
        for (DiagramPanel dPanel : this.diagramToSessionMap.keySet())
        {
            NetworkSession aSession = (NetworkSession) this.diagramToSessionMap.get(dPanel);
            if (aSession.equals(session))
            {
                return dPanel;
            }
        }
        return null;
    }

    /**
     * Returns all diagram panels attached to sessions
     * 
     * @return array
     */
    public DiagramPanel[] getSharedDiagramPanels()
    {
        Set<DiagramPanel> diagramPanelSet = this.diagramToSessionMap.keySet();
        return (DiagramPanel[]) diagramPanelSet.toArray(new DiagramPanel[diagramPanelSet.size()]);
    }

    /**
     * Singleton Instance
     */
    private static NetworkManager instance;

    private EventListenerList listeners = new EventListenerList();
    
    //private Vector listeners = new Vector();

    private NetworkAction action = new NetworkAction();

    /**
     * Contaisn relationships between sessions and diagram panels
     */
    private Map<DiagramPanel, NetworkSession> diagramToSessionMap = new HashMap<DiagramPanel, NetworkSession>();

}
