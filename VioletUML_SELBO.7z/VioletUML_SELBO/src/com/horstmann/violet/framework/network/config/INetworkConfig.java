/*
 * Projet     : 
 * Package    : com.horstmann.violet.framework.network.config
 * Auteur     : a.depellegrin
 * Cr?? le    : 11 juil. 2007
 */
package com.horstmann.violet.framework.network.config;


public interface INetworkConfig
{
    /**
     * Initializes object with user preferences
     */
    public void loadPreferedValues();
    
    /**
     * Saves current values to user preferences
     */
    public void savePreferedValues();
    
    /**
     * @return object clone
     * @throws CloneNotSupportedException
     */
    public Object clone() throws CloneNotSupportedException;
    
}
