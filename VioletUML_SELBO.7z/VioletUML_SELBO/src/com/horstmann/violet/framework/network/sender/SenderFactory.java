package com.horstmann.violet.framework.network.sender;

import java.net.URL;

import com.horstmann.violet.framework.network.NetworkConstant;

/**
 * 
 * @author Victor Freches
 * 
 */
public class SenderFactory
{

    private SenderFactory()
    {

    }

    public static SenderFactory getInstance()
    {
        if (SenderFactory.instance == null)
        {
            SenderFactory.instance = new SenderFactory();
        }
        return SenderFactory.instance;
    }

    public ISender createSender(URL senderURL)
    {
        String protocol = senderURL.getProtocol();
        if (protocol == null) {
            throw new RuntimeException("Can't read network protocol");
        }
        if (protocol.toLowerCase().equals(NetworkConstant.HTTP_PROTOCOL)) {
            return new HTTPSender();
        }
        throw new RuntimeException("Can't recognize network protcol");
    }

    private static SenderFactory instance;

}
