package com.horstmann.violet.framework.util;

public class UniqueIDGenerator
{
    public static synchronized String getNewId() {
        lastId++;
        return "" + lastId;
    }

    private static int lastId = 0;
}
