package com.horstmann.violet.framework.diagram;

import java.beans.PropertyChangeEvent;


/**
 * Implement this interface and register it a Graph class instance to
 * be informed about modifications.
 * 
 * @author Cay Horstmann
 *
 */
public interface GraphModificationListener
{
    void nodeAdded(Graph g, Node n);
    void nodeRemoved(Graph g, Node n);
    void nodeMoved(Graph g, Node n, double dx, double dy);
    void childAttached(Graph g, int index, Node p, Node c);
    void childDetached(Graph g, int index, Node p, Node c);
    void edgeAdded(Graph g, Edge e);
    void edgeRemoved(Graph g, Edge e);
    void propertyChangedOnNodeOrEdge(Graph g, PropertyChangeEvent event);
    
}
