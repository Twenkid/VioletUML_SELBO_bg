package com.horstmann.violet.framework.gui;

public class GraphPanelEventType
{

    private GraphPanelEventType(String eventType)
    {
        this.eventType = eventType;
    }

    public String toString()
    {
        return eventType;
    }

    private String eventType;

    public static final GraphPanelEventType NODE_ADDED = new GraphPanelEventType("nodeAdded");
    public static final GraphPanelEventType NODE_UDPATED = new GraphPanelEventType("nodeUpdated");
    public static final GraphPanelEventType NODE_REMOVED = new GraphPanelEventType("nodeRemoved");
    public static final GraphPanelEventType EDGE_ADDED = new GraphPanelEventType("edgeAdded");
    public static final GraphPanelEventType EDGE_UDPATED = new GraphPanelEventType("edgeUpdated");
    public static final GraphPanelEventType EDGE_REMOVED = new GraphPanelEventType("edgeRemoved");

}
