/*
 Violet - A program for editing UML diagrams.

 Copyright (C) 2007 Cay S. Horstmann (http://horstmann.com)
 Alexandre de Pellegrin (http://alexdp.free.fr);

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.horstmann.violet.framework.gui.sidebar;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JLabel;
import javax.swing.border.MatteBorder;

import com.horstmann.violet.framework.gui.DiagramPanel;
import com.horstmann.violet.framework.gui.theme.ThemeManager;
import com.horstmann.violet.framework.resources.ResourceBundleConstant;
import com.horstmann.violet.framework.swingextension.CollapsiblePane;
import com.l2fprod.common.swing.JTaskPane;
import com.l2fprod.common.swing.JTaskPaneGroup;

public class SideBar extends CollapsiblePane
{

    public SideBar(DiagramPanel diagramPanel)
    {
        super();
        this.diagramPanel = diagramPanel;
        taskPane = new JTaskPane();
        add(taskPane);
        show(SIDE_MANDATORY_SHORTCUT_PANEL, true);
        show(SIDE_TOOL_PANEL, true);
        show(SIDE_OPTIONAL_SHORTCUT_PANEL, true);
        setBorder(new MatteBorder(0, 1, 0, 0, ThemeManager.getInstance().getTheme().getSIDEBAR_BORDER_COLOR()));
        fixWidth();
    }

    private void fixWidth()
    {
        JLabel sizer = new JLabel();
        sizer.setPreferredSize(new Dimension(215, 1));
        taskPane.add(sizer);
    }

    public void show(int sidePanelId, boolean isVisible)
    {
        switch (sidePanelId)
        {
        case SIDE_MANDATORY_SHORTCUT_PANEL:
            if (isVisible)
            {
                this.addElement(this.getSideShortcutMandatoryPanel(), this.getSideBarResourceBundle().getString(
                        "title.standardbuttons"));
            }
            break;
        case SIDE_TOOL_PANEL:
            if (isVisible)
            {
                this.addElement(this.getSideToolPanel(), this.getSideBarResourceBundle().getString("title.diagramtools"));
            }
            break;
        case SIDE_OPTIONAL_SHORTCUT_PANEL:
            if (isVisible)
            {
                this.addElement(this.getSideShortcutOptionalPanel(), this.getSideBarResourceBundle().getString(
                        "title.extendedfunctions"));
            }
            break;

        default:
            break;
        }
    }

    private void addElement(final Component c, String title)
    {
        JTaskPaneGroup group = new JTaskPaneGroup();
        group.setFont(group.getFont().deriveFont(Font.PLAIN));
        group.setTitle(title);
        group.setLayout(new BorderLayout());
        group.add(c, BorderLayout.CENTER);
        taskPane.add(group);
    }

    public SideToolPanel getSideToolPanel()
    {
        if (this.sideToolPanel == null)
        {
            this.sideToolPanel = new SideToolPanel(this.diagramPanel.getGraphPanel().getGraph());
        }
        return this.sideToolPanel;
    }

    private SideShortcutMandatoryPanel getSideShortcutMandatoryPanel()
    {
        if (this.sideShortcutMandatoryPanel == null)
        {
            this.sideShortcutMandatoryPanel = new SideShortcutMandatoryPanel(this.diagramPanel, this.getSideBarResourceBundle());
        }
        return this.sideShortcutMandatoryPanel;
    }

    private SideShortcutOptionalPanel getSideShortcutOptionalPanel()
    {
        if (this.sideShortcutOptionalPanel == null)
        {
            this.sideShortcutOptionalPanel = new SideShortcutOptionalPanel(this.diagramPanel, this.getSideBarResourceBundle());
        }
        return this.sideShortcutOptionalPanel;
    }

    /**
     * @return resource bundle
     */
    private ResourceBundle getSideBarResourceBundle()
    {
        if (this.resourceBundle == null)
        {
            this.resourceBundle = ResourceBundle.getBundle(ResourceBundleConstant.SIDEBAR_STRINGS, Locale.getDefault());
        }
        return this.resourceBundle;
    }

    public static final int SIDE_MANDATORY_SHORTCUT_PANEL = 0;
    public static final int SIDE_TOOL_PANEL = 1;
    public static final int SIDE_OPTIONAL_SHORTCUT_PANEL = 2;

    private DiagramPanel diagramPanel;
    private SideToolPanel sideToolPanel;
    private SideShortcutMandatoryPanel sideShortcutMandatoryPanel;
    private SideShortcutOptionalPanel sideShortcutOptionalPanel;
    private JTaskPane taskPane;
    private ResourceBundle resourceBundle;

}
