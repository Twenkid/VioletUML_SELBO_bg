/*
 Violet - A program for editing UML diagrams.

 Copyright (C) 2007 Cay S. Horstmann (http://horstmann.com)
 Alexandre de Pellegrin (http://alexdp.free.fr);

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.horstmann.violet.framework.gui.sidebar;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.horstmann.violet.framework.action.FileAction;
// import com.horstmann.violet.framework.action.HelpAction;
import com.horstmann.violet.framework.gui.DiagramPanel;
import com.horstmann.violet.framework.gui.theme.ThemeManager;
import com.horstmann.violet.framework.network.NetworkAction;
import com.horstmann.violet.framework.resources.ResourceFactory;
import com.horstmann.violet.framework.swingextension.IconButtonUI;

public class SideShortcutOptionalPanel extends JPanel
{

    /**
     * Default contructor
     */
    public SideShortcutOptionalPanel(DiagramPanel diagramPanel, ResourceBundle sideBarResourceBundle)
    {
        this.diagramPanel = diagramPanel;
        // this.helpAction = new HelpAction();
        this.fileAction = new FileAction();
        this.networkAction = new NetworkAction();

        setBackground(ThemeManager.getInstance().getTheme().getSIDEBAR_ELEMENT_BACKGROUND_COLOR());
        ResourceFactory factory = new ResourceFactory(sideBarResourceBundle);

        JButton bHelp = factory.createButton("help");
        bHelp.setUI(new IconButtonUI());
        bHelp.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                performShowHelp();
            }
        });

        JButton bPrint = factory.createButton("print");
        bPrint.setUI(new IconButtonUI());
        bPrint.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                performPrint();
            }
        });

        JButton bExportToClipboard = factory.createButton("export_to_clipboard");
        bExportToClipboard.setUI(new IconButtonUI());
        bExportToClipboard.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                performExportToClipboard();
            }
        });

        JButton bShareDocument = factory.createButton("share_document");
        bShareDocument.setUI(new IconButtonUI());
        bShareDocument.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                performShareDocument();
            }
        });

        JPanel panel = new JPanel();
        GridLayout layout = new GridLayout(1, 2);
        layout.setHgap(15);
        panel.setLayout(layout);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(0, 5, 0, 0));
        panel.add(bExportToClipboard);
        panel.add(bPrint);
        // panel.add(bShareDocument);

        setLayout(new FlowLayout(FlowLayout.LEFT));
        add(panel);
    }

    private void performShowHelp()
    {
        // TODO : insert direct link to website
    }

    private void performPrint()
    {
        fileAction.print(diagramPanel);
    }

    private void performExportToClipboard()
    {
        fileAction.exportToClipboard(diagramPanel);
    }

    private void performShareDocument()
    {
        networkAction.shareDiagramPanel(diagramPanel);
    }

    /**
     * "Help" action manager
     */
    // never used
    // private HelpAction helpAction;

    /**
     * "File" action manager
     */
    private FileAction fileAction;

    /**
     * "Network" action manager
     */
    private NetworkAction networkAction;

    /**
     * Current diagram panel
     */
    private DiagramPanel diagramPanel;
    
    

}
