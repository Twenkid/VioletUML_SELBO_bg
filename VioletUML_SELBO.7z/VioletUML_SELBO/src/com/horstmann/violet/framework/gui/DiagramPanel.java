/*
 Violet - A program for editing UML diagrams.

 Copyright (C) 2007 Cay S. Horstmann (http://horstmann.com)
 Alexandre de Pellegrin (http://alexdp.free.fr);

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.horstmann.violet.framework.gui;

import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.beans.PropertyChangeEvent;
import java.io.File;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import com.horstmann.violet.framework.diagram.Edge;
import com.horstmann.violet.framework.diagram.Graph;
import com.horstmann.violet.framework.diagram.GraphModificationListener;
import com.horstmann.violet.framework.diagram.Node;
import com.horstmann.violet.framework.gui.menu.MenuFactory;
import com.horstmann.violet.framework.gui.sidebar.SideBar;
import com.horstmann.violet.framework.gui.sidebar.SideToolPanel;
import com.horstmann.violet.framework.gui.theme.ThemeManager;
import com.horstmann.violet.framework.network.NetworkAction;
import com.horstmann.violet.framework.resources.ResourceBundleConstant;
import com.horstmann.violet.framework.util.UniqueIDGenerator;
import com.horstmann.violet.product.diagram.activity.ActivityDiagramGraph;
import com.horstmann.violet.product.diagram.classes.ClassDiagramGraph;
import com.horstmann.violet.product.diagram.object.ObjectDiagramGraph;
import com.horstmann.violet.product.diagram.sequence.SequenceDiagramGraph;
import com.horstmann.violet.product.diagram.state.StateDiagramGraph;
import com.horstmann.violet.product.diagram.usecase.UseCaseDiagramGraph;



import com.horstmann.violet.framework.*;
/**
 * A diagram panel for showing a graphical diagram
 */
public class DiagramPanel extends JPanel
{
    /**
     * Constructs a diagram panel containing a graph
     * 
     * @param aGraph the initial graph
     */
    public DiagramPanel(Graph aGraph)
    {
        this.instance = this;
        setGraph(aGraph);
    }

    /**
     * Constructs a diagram panel ready to contain a graph. To be able to recognize it, we set an id to it.
     * 
     * @param id
     */
    public DiagramPanel(String id)
    {
        this.instance = this;
        this.id = id;
    }

    /**
     * Sets a graph to this panel
     * 
     * @param aGraph
     */
    public void setGraph(Graph aGraph)
    {
        reset();
        this.graph = aGraph;

        setDefaultTitle(this.graph);
        LayoutManager layout = new BorderLayout();
        setLayout(layout);

        SideBar sBar = getSideBar(aGraph);
        JScrollPane scrollGPanel = getScrollableGraphPanel(aGraph, sBar);
        StatusBar statBar = getStatusBar(sBar);

        add(scrollGPanel, BorderLayout.CENTER);
        add(sBar, BorderLayout.EAST);
        add(statBar, BorderLayout.SOUTH);

        addGraphPanelListener();

        // Update title when graph dirty state changes
        graph.addGraphModificationListener(new GraphModificationListener()
        {
            public void childAttached(Graph g, int index, Node p, Node c)
            {
                setSaveNeeded(true);
            }

            public void childDetached(Graph g, int index, Node p, Node c)
            {
                setSaveNeeded(true);
            }

            public void edgeAdded(Graph g, Edge e)
            {
                setSaveNeeded(true);
            }

            public void edgeRemoved(Graph g, Edge e)
            {
                setSaveNeeded(true);
            }

            public void nodeAdded(Graph g, Node n)
            {
                setSaveNeeded(true);
            }

            public void nodeRemoved(Graph g, Node n)
            {
                setSaveNeeded(true);
            }

            public void nodeMoved(Graph g, Node n, double dx, double dy)
            {
                setSaveNeeded(true);
            }

            public void propertyChangedOnNodeOrEdge(Graph g, PropertyChangeEvent event)
            {
                setSaveNeeded(true);
            }
        });
        
        
        
        /*
        JMenuBar menuBar = new JMenuBar();
        // TODO : Font change has not effect
        menuBar.setFont(ThemeManager.getInstance().getTheme().getMENUBAR_FONT());
        MenuFactory menuFactory = getMenuFactory();
                
        //menuBar.add(menuFactory.getViewMenu(this.ownerFrame));
        
        menuBar.add(menuFactory.getEditMenu(this));
        menuBar.add(menuFactory.getViewMenu(this));
        
        menuBar.add(menuFactory.getHelpMenu(this.ownerFrame));
        //menuBar.add(menuFactory.getLanguageMenu(this));
        

        editorPanel.add(menuBar, BorderLayout.NORTH);
        */
    }

    /*
    public MenuFactory getMenuFactory()
    {
        if (this.menuFactory == null)
        {
            menuFactory = new MenuFactory();
        }
        return this.menuFactory;
    }
    */
    
    private void reset()
    {
        this.removeAll();
        this.graph = null;
        this.graphPanel = null;
        this.sideBar = null;
        this.scrollableGraphPanel = null;
        this.statusBar = null;
        this.filePath = null;
        this.title = null;
        this.listeners = new Vector<DiagramPanelListener>();
    }

    public SideBar getSideBar(Graph graph)
    {
        if (this.sideBar == null)
        {
            this.sideBar = new SideBar(this);
        }
        return this.sideBar;
    }

    public JScrollPane getScrollableGraphPanel(Graph graph, SideBar sideBar)
    {
        if (this.scrollableGraphPanel == null)
        {
            final GraphPanel panel = this.getGraphPanel();
            final Point startDragLocation = new Point(-1, -1);
            panel.repaint();
            final SideToolPanel sideToolPanel = sideBar.getSideToolPanel();
            panel.addMouseListener(new MouseAdapter()
            {
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getButton() == MouseEvent.BUTTON3)
                    {
                        sideToolPanel.reset();
                        startDragLocation.setLocation(e.getPoint());
                    }
                }

                @Override
                public void mouseReleased(MouseEvent arg0)
                {
                    startDragLocation.setLocation(-1, -1);
                }

            });
            panel.addMouseMotionListener(new MouseMotionAdapter()
            {
                @Override
                public void mouseDragged(MouseEvent e)
                {
                    if (e.getButton() == MouseEvent.BUTTON3)
                    {
                        if (startDragLocation.getX() == -1 && startDragLocation.getY() == -1)
                        {
                            startDragLocation.setLocation(e.getX() - panel.getX(), e.getY() - panel.getY());
                        }
                        panel.setLocation((int) startDragLocation.getX() - e.getY(), (int) startDragLocation.getY() - e.getY());
                    }
                }

            });
            panel.addMouseWheelListener(new MouseWheelListener()
            {
                public void mouseWheelMoved(MouseWheelEvent e)
                {
                    int scroll = e.getUnitsToScroll();
                    if (scroll > 0)
                    {
                        sideToolPanel.selectNextButton();
                    }
                    if (scroll < 0)
                    {
                        sideToolPanel.selectPreviousButton();
                    }
                }
            });
            panel.addKeyListener(new KeyAdapter()
            {
                public void keyPressed(KeyEvent e)
                {
                    if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
                    {
                        sideToolPanel.reset();
                    }
                }
            });
            sideBar.getSideToolPanel().addListener(panel.getToolListener());
            this.scrollableGraphPanel = new JScrollPane(panel);
            this.scrollableGraphPanel.setBackground(ThemeManager.getInstance().getTheme().getWHITE_COLOR());
            this.scrollableGraphPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
        }
        return this.scrollableGraphPanel;
    }

    private StatusBar getStatusBar(SideBar sideBar)
    {
        if (this.statusBar == null)
        {
            this.statusBar = new StatusBar(sideBar);
        }
        return this.statusBar;
    }

    public GraphPanel getGraphPanel()
    {
        if (this.graphPanel == null)
        {
            this.graphPanel = new GraphPanel(this.graph);
        }
        return this.graphPanel;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String newValue)
    {
        title = newValue;
        fireTitleChanged(newValue);
    }

    private void setDefaultTitle(Graph graph)
    {
        ResourceBundle rb = ResourceBundle.getBundle(ResourceBundleConstant.MENU_STRINGS, Locale.getDefault());
        if (graph instanceof ClassDiagramGraph) title = rb.getString("file.new.class_diagram.text");
        else if (graph instanceof ObjectDiagramGraph) title = rb.getString("file.new.object_diagram.text");
        else if (graph instanceof SequenceDiagramGraph) title = rb.getString("file.new.sequence_diagram.text");
        else if (graph instanceof StateDiagramGraph) title = rb.getString("file.new.state_diagram.text");
        else if (graph instanceof UseCaseDiagramGraph) title = rb.getString("file.new.usecase_diagram.text");
        else if (graph instanceof ActivityDiagramGraph) title = rb.getString("file.new.activity_diagram.text");
        else title = "Unknown";
    }

    /**
     * Gets the fileName property.
     * 
     * @return the file path
     */
    public String getFilePath()
    {
        return filePath;
    }

    /**
     * Sets the fileName property.
     * 
     * @param path the file path
     */
    public void setFilePath(String path)
    {
        filePath = path;
        File file = new File(path);
        setTitle(file.getName());
    }

    public boolean isSaveNeeded()
    {
        return this.isSaveNeeded;
    }

    public void setSaveNeeded(boolean isSaveNeeded)
    {
        this.isSaveNeeded = isSaveNeeded;
        if (isSaveNeeded)
        {
            if (!title.endsWith("*"))
            {
                setTitle(title + "*");
            }
            fireSaveNeeded();
        }
        if (!isSaveNeeded)
        {
            if (title.endsWith("*"))
            {
                setTitle(title.substring(0, title.length() - 1));
            }
        }
    }

    private void addGraphPanelListener()
    {
        this.getGraphPanel().addListener(new GraphPanelListener()
        {
            public void eventHappenedOnEdge(GraphPanelEventType type, Edge e)
            {
                if (type.equals(GraphPanelEventType.EDGE_ADDED))
                {
                    getNetworkAction().sendAddedEdge(instance, e);
                }
                if (type.equals(GraphPanelEventType.EDGE_UDPATED))
                {
                    getNetworkAction().sendModifiedEdge(instance, e);
                }
                if (type.equals(GraphPanelEventType.EDGE_REMOVED))
                {
                    getNetworkAction().sendRemovedEdge(instance, e);
                }
            }

            public void eventHappenedOnNode(GraphPanelEventType type, Node n)
            {
                if (type.equals(GraphPanelEventType.NODE_ADDED))
                {
                    getNetworkAction().sendAddedNode(instance, n);
                }
                if (type.equals(GraphPanelEventType.NODE_UDPATED))
                {
                    getNetworkAction().sendModifiedNode(instance, n);
                }
                if (type.equals(GraphPanelEventType.NODE_REMOVED))
                {
                    getNetworkAction().sendRemovedNode(instance, n);
                }
            }

        });
    }

    public synchronized void addListener(DiagramPanelListener l)
    {
        if (!this.listeners.contains(l))
        {
            this.listeners.addElement(l);
        }
    }

    private void fireTitleChanged(String newTitle)
    {
        Vector<DiagramPanelListener> tl = cloneListeners();
        int size = tl.size();
        if (size == 0) return;

        for (int i = 0; i < size; ++i)
        {
            DiagramPanelListener aListener = (DiagramPanelListener) tl.elementAt(i);
            aListener.titleChanged(newTitle);
        }
    }

    @SuppressWarnings("unchecked")
    private synchronized Vector<DiagramPanelListener> cloneListeners()
    {
        return (Vector<DiagramPanelListener>) this.listeners.clone();
    }

    /**
     * Fire an event to all listeners by calling
     */
    public void fireMustOpenFile(URL url)
    {
        Vector<DiagramPanelListener> tl = cloneListeners();
        int size = tl.size();
        if (size == 0) return;
        for (int i = 0; i < size; ++i)
        {
            DiagramPanelListener l = (DiagramPanelListener) tl.elementAt(i);
            l.mustOpenfile(url);
        }
    }

    /**
     * Fire an event to all listeners by calling
     */
    private void fireSaveNeeded()
    {
        Vector<DiagramPanelListener> tl = cloneListeners();
        int size = tl.size();
        if (size == 0) return;
        for (int i = 0; i < size; ++i)
        {
            DiagramPanelListener l = (DiagramPanelListener) tl.elementAt(i);
            l.graphCouldBeSaved();
        }
    }

    public String getId()
    {
        if (this.id == null)
        {
            this.id = UniqueIDGenerator.getNewId();
        }
        return this.id;
    }

    private NetworkAction getNetworkAction()
    {
        if (this.networkAction == null)
        {
            this.networkAction = new NetworkAction();
        }
        return this.networkAction;
    }


    public void repaintGraph()
    {
       this.repaint();
    }
    
    private Graph graph;
    private GraphPanel graphPanel;
    private SideBar sideBar;
    private JScrollPane scrollableGraphPanel;
    private StatusBar statusBar;
    private String filePath;
    private String title;
    private Vector<DiagramPanelListener> listeners = new Vector<DiagramPanelListener>();
    private String id;
    private DiagramPanel instance;
    private NetworkAction networkAction;
    private boolean isSaveNeeded = false;
    
    
}
