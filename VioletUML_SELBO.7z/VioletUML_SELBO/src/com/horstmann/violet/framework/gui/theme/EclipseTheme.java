/*
 Violet - A program for editing UML diagrams.

 Copyright (C) 2007 Cay S. Horstmann (http://horstmann.com)
                    Alexandre de Pellegrin (http://alexdp.free.fr);

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.horstmann.violet.framework.gui.theme;

import java.awt.Color;
import java.awt.Font;

import javax.swing.plaf.metal.MetalLookAndFeel;

import com.horstmann.violet.eclipseplugin.editors.EclipseColorPicker;

/**
 * Eclipse theme used when the software run as an embedded plugin
 * 
 * @author Alexandre de Pellegrin
 *
 */
public class EclipseTheme extends AbstractTheme
{
    
    
    /**
     * Default constructor
     * 
     * @param colorManager handles color from the Eclipse environement
     */
    public EclipseTheme(EclipseColorPicker colorManager)
    {
        this.colorManager = colorManager;
    }

    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.gui.laf.AbstractTheme#getLookAndFeel()
     */
    protected String getLookAndFeelClassName()
    {
        return MetalLookAndFeel.class.getName();
    }
    
    /* (non-Javadoc)
     * @see com.horstmann.violet.framework.gui.theme.AbstractTheme#setup()
     */
    protected void setup()
    {
    }    

    public Color getBLACK_COLOR() {return Color.BLACK;}
    public Color getWHITE_COLOR() {return Color.WHITE;}

    public Color getGRID_COLOR() {return new Color(192, 220, 242);}

    public Color getBACKGROUND_COLOR() {return colorManager.getBackGroundColor();}
    
    public Font getMENUBAR_FONT() {return MetalLookAndFeel.getMenuTextFont();}
    public Color getMENUBAR_BACKGROUND_COLOR() {return colorManager.getBackGroundColor();}
    public Color getMENUBAR_FOREGROUND_COLOR() {return colorManager.getForeGroundColor();}
    
    public Color getROLLOVERBUTTON_DEFAULT_COLOR() {return colorManager.getBackGroundColor();}
    public Color getROLLOVERBUTTON_ROLLOVER_BORDER_COLOR() {return colorManager.getForeGroundColor();}
    public Color getROLLOVERBUTTON_ROLLOVER_COLOR() {return colorManager.getBackGroundColor();}

    public Color getSIDEBAR_BACKGROUND_END_COLOR() {return colorManager.getBackGroundColor();}
    public Color getSIDEBAR_BACKGROUND_START_COLOR() {return colorManager.getBackGroundColor();}
    public Color getSIDEBAR_BORDER_COLOR() {return colorManager.getNormalShadowColor();}
    public Color getSIDEBAR_ELEMENT_BACKGROUND_COLOR() {return colorManager.getBackGroundColor();}
    public Color getSIDEBAR_ELEMENT_TITLE_BG_END_COLOR() {return colorManager.getTitleBgColorGradient();}
    public Color getSIDEBAR_ELEMENT_TITLE_BG_START_COLOR() {return colorManager.getTitleBgColor();}
    public Color getSIDEBAR_ELEMENT_TITLE_FOREGROUND_COLOR() {return colorManager.getTitleFgColor();}
    public Color getSIDEBAR_ELEMENT_TITLE_OVER_COLOR() {return colorManager.getTitleFgColor().brighter();}
    
    public Color getSTATUSBAR_BACKGROUND_COLOR() {return colorManager.getBackGroundColor();}
    public Color getSTATUSBAR_BORDER_COLOR() {return colorManager.getNormalShadowColor();}
    
    public Font getTOGGLEBUTTON_FONT() {return MetalLookAndFeel.getMenuTextFont().deriveFont(Font.PLAIN);}
    public Color getTOGGLEBUTTON_SELECTED_BORDER_COLOR() {return new Color(107, 144, 188);}
    public Color getTOGGLEBUTTON_SELECTED_COLOR() {return new Color(192, 220, 242);}
    public Color getTOGGLEBUTTON_UNSELECTED_COLOR() {return getSIDEBAR_ELEMENT_BACKGROUND_COLOR();}
    
    public Font getWELCOME_SMALL_FONT() {return MetalLookAndFeel.getWindowTitleFont().deriveFont((float) 12.0).deriveFont(Font.PLAIN);}
    public Font getWELCOME_BIG_FONT() {return MetalLookAndFeel.getWindowTitleFont().deriveFont((float) 28.0);}
    public Color getWELCOME_BACKGROUND_END_COLOR() {return getSIDEBAR_BACKGROUND_START_COLOR();}
    public Color getWELCOME_BACKGROUND_START_COLOR() {return getSIDEBAR_BACKGROUND_END_COLOR().brighter();}
    public Color getWELCOME_BIG_FOREGROUND_COLOR() {return Color.WHITE;}
    public Color getWELCOME_BIG_ROLLOVER_FOREGROUND_COLOR() {return new Color(255, 203, 151);}

    
    /**
     * Contains Eclipse colors 
     */
    private EclipseColorPicker colorManager;

}
