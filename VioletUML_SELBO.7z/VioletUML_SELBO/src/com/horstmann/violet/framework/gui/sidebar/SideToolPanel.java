/*
 Violet - A program for editing UML diagrams.

 Copyright (C) 2007 Cay S. Horstmann (http://horstmann.com)
 Alexandre de Pellegrin (http://alexdp.free.fr);

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.horstmann.violet.framework.gui.sidebar;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JPanel;

import com.horstmann.violet.framework.diagram.Edge;
import com.horstmann.violet.framework.diagram.Graph;
import com.horstmann.violet.framework.diagram.Node;
import com.horstmann.violet.framework.gui.theme.Theme;
import com.horstmann.violet.framework.gui.theme.ThemeManager;
import com.horstmann.violet.framework.resources.ResourceBundleUtils;
import com.horstmann.violet.framework.swingextension.CustomToggleButton;

/**
 * A tool bar that contains node and edge prototype icons. Exactly one icon is selected at any time.
 */
public class SideToolPanel extends JPanel
{
    /**
     * Constructs a tool bar with no icons.
     */
    public SideToolPanel(Graph graph)
    {
        tools = getTools(graph);
        toggleButtons = getToggleButtons(tools);
        JPanel buttonPanel = getButtonPanel(toggleButtons);
        setLayout(new BorderLayout());
        add(buttonPanel, BorderLayout.CENTER);
        setBackground(ThemeManager.getInstance().getTheme().getSIDEBAR_ELEMENT_BACKGROUND_COLOR());
        reset();
    }

    /**
     * Returns tools associated to a graph
     * 
     * @param graph
     * @return tools array
     */
    private Tool[] getTools(Graph graph)
    {
        Node[] nodeTypes = graph.getNodePrototypes();
        Edge[] edgeTypes = graph.getEdgePrototypes();
        int length = nodeTypes.length + edgeTypes.length + 1;
        ResourceBundle graphResources = ResourceBundleUtils.getStringsResourceBundleForObject(graph);
        Tool[] tools = new Tool[length];
        tools[0] = getSelectionTool();
        int j = 1;
        for (int i = 0; i < nodeTypes.length; i++)
        {
            String label = graphResources.getString("node" + (i + 1) + ".tooltip");
            Tool aTool = new Tool(nodeTypes[i], label);
            tools[j] = aTool;
            j++;
        }
        for (int i = 0; i < edgeTypes.length; i++)
        {
            String label = graphResources.getString("edge" + (i + 1) + ".tooltip");
            Tool aTool = new Tool(edgeTypes[i], label);
            tools[j] = aTool;
            j++;
        }
        return tools;
    }

    /**
     * @return selection tool (which refers to a special constructor
     */
    private Tool getSelectionTool()
    {
        return new Tool();
    }

    /**
     * @return curretly selected tool
     */
    public Tool getSelectedTool()
    {
        for (int i = 0; i < toggleButtons.length; i++)
        {
            CustomToggleButton button = toggleButtons[i];
            if (button.isSelected())
            {
                return tools[i];
            }
        }
        reset();
        return tools[0];
    }

    /**
     * @param diagram tools
     * @return buttons representing tools
     */
    private CustomToggleButton[] getToggleButtons(Tool[] tools)
    {
        CustomToggleButton[] buttons = new CustomToggleButton[tools.length];
        for (int i = 0; i < tools.length; i++)
        {
            final Tool aTool = tools[i];
            Theme cLAF = ThemeManager.getInstance().getTheme();
            final CustomToggleButton button = new CustomToggleButton(aTool.getLabel(), aTool.getIcon(), cLAF
                    .getTOGGLEBUTTON_SELECTED_COLOR(), cLAF.getTOGGLEBUTTON_SELECTED_BORDER_COLOR(), cLAF
                    .getTOGGLEBUTTON_UNSELECTED_COLOR());

            buttons[i] = button;
        }
        return buttons;
    }

    /**
     * Performs button select
     * 
     * @param selectedButton to be considered as selected
     */
    private void setSelectedButton(CustomToggleButton selectedButton)
    {
        for (int i = 0; i < toggleButtons.length; i++)
        {
            CustomToggleButton button = toggleButtons[i];
            if (button != selectedButton)
            {
                button.setSelected(false);
            }
            if (button == selectedButton)
            {
                button.setSelected(true);
                fireToolChangeEvent(tools[i]);
            }
        }
    }

    /**
     * Select next button
     */
    public void selectNextButton()
    {
        for (int i = 0; i < toggleButtons.length; i++)
        {
            CustomToggleButton button = toggleButtons[i];
            if (button.isSelected())
            {
                if (i < toggleButtons.length - 1)
                {
                    setSelectedButton(toggleButtons[i + 1]);
                    return;
                }
            }
        }
    }

    /**
     * Select previous button
     */
    public void selectPreviousButton()
    {
        for (int i = 0; i < toggleButtons.length; i++)
        {
            CustomToggleButton button = toggleButtons[i];
            if (button.isSelected())
            {
                if (i > 0)
                {
                    setSelectedButton(toggleButtons[i - 1]);
                    return;
                }
            }
        }
    }

    /**
     * Creates a panel that contains custom toggle buttons. Also sets mouse listeners.
     * 
     * @param buttons to be added to this panel
     * @return JPanel
     */
    private JPanel getButtonPanel(CustomToggleButton[] buttons)
    {
        JPanel buttonPanel = new JPanel();
        for (int i = 0; i < buttons.length; i++)
        {
            final CustomToggleButton button = buttons[i];
            button.addMouseListener(new MouseAdapter()
            {
                public void mouseClicked(MouseEvent arg0)
                {
                    setSelectedButton(button);
                }
            });
            buttonPanel.add(button);
        }

        buttonPanel.setLayout(new GridLayout(0, 1));
        buttonPanel.addMouseWheelListener(new MouseWheelListener()
        {

            public void mouseWheelMoved(MouseWheelEvent e)
            {
                int scroll = e.getUnitsToScroll();
                if (scroll > 0)
                {
                    selectNextButton();
                }
                if (scroll < 0)
                {
                    selectPreviousButton();
                }
            }

        });
        return buttonPanel;
    }

    /**
     * Remenbers selected tool and informs all listeners about this change
     * 
     * @param nodeOrEdge
     */
    private void fireToolChangeEvent(Tool tool)
    {
        Iterator<Listener> it = this.listeners.iterator();
        while (it.hasNext())
        {
            Listener listener = it.next();
            listener.toolSelectionChanged(tool);
        }
    }

    /**
     * Resets tool selection by selecting the first of the list
     */
    public void reset()
    {
        if (toggleButtons.length > 0)
        {
            setSelectedButton(toggleButtons[0]);
        }
    }

    /**
     * Listener to be implmenented and registered by each class that needs to know toolbar actions
     * 
     * @author Alexandre de Pellegrin
     * 
     */
    public interface Listener
    {

        /**
         * Invoked when a tool is selected
         * 
         * @param selectedNodeOrEdge the selected tool
         */
        void toolSelectionChanged(Tool selectedTool);

    }

    /**
     * Declares a new listener
     * 
     * @param listener
     */
    public void addListener(Listener listener)
    {
        this.listeners.add(listener);
    }

    private List<Listener> listeners = new ArrayList<Listener>();
    private Tool[] tools;
    private CustomToggleButton[] toggleButtons;

}