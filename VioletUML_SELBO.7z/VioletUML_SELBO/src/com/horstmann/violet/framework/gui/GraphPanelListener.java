package com.horstmann.violet.framework.gui;

import com.horstmann.violet.framework.diagram.Edge;
import com.horstmann.violet.framework.diagram.Node;

public interface GraphPanelListener
{
    public void eventHappenedOnNode(GraphPanelEventType type, Node n);
    public void eventHappenedOnEdge(GraphPanelEventType type, Edge n);
    
}
